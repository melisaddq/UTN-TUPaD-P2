
package TP3_IntroPOO;


public class Gallina {
/*Gestión de Gallinas en Granja Digital
a. Crear una clase Gallina con los atributos: idGallina, edad, huevosPuestos.
Métodos requeridos: ponerHuevo(), envejecer(), mostrarEstado().
Tarea: Crear dos gallinas, simular sus acciones (envejecer y poner huevos), y mostrar su estado.*/   
    
// ATRIBUTOS

private String idGallina;
private int edad;
private int huevosPuestos;

// MÉTODOS

public void MostrarEstado() {
    System.out.println("Estado de la gallina " + idGallina + ":\nEdad:  " + edad + " meses \nHuevos Puestos: " + huevosPuestos);
      }

 public int ponerHuevo() {
    huevosPuestos += 1;
    return huevosPuestos;
 }
    
public int envejecer() {
    edad += 1;
    return edad;
}

// SETTERS

public void setIdGallina(String idGallina) {
    if (idGallina != null){
    this.idGallina = idGallina;
    }
}

public void setEdad(int edad) {
    this.edad = edad;
}

// GETTERS

   
    
}
