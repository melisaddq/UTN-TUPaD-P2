
package TP3_IntroPOO;


public class NaveEspacial {
/*Simulación de Nave Espacial
Crear una clase NaveEspacial con los atributos: nombre, combustible.
Métodos requeridos: despegar(), avanzar(distancia), recargarCombustible(cantidad), mostrarEstado().
Reglas: Validar que haya suficiente combustible antes de avanzar y evitar que se supere el límite al recargar.
Tarea: Crear una nave con 50 unidades de combustible, intentar avanzar sin recargar, luego recargar y avanzar correctamente. Mostrar el estado al final.*/
    
// ATRIBUTOS

private String nombre;
private int combustible;

private final int MAX_COMBUSTIBLE = 100;

// MÉTODOS

    public void MostrarEstado() {
        System.out.println("Estado de la nave espacial " + nombre + ":\nCombustible:  " + combustible);
        }

    public int recargarCombustible(int cantidad){
        if ((combustible + cantidad) > MAX_COMBUSTIBLE ){
            System.out.println("Usted supera el máximo a recargar, pruebe cargar menos combustible \nActualmente cuenta con: " + combustible + " litros");
        } else{
            System.out.println("Usted ha recargado " + cantidad + " litros");
            combustible += cantidad;
        }   
        return combustible;
    }

    public void avanzar(int distancia) {
        int consumo = distancia * 2; // Suponiendo que consume 2x1
        if (combustible >= consumo) {
            combustible -= consumo;
            System.out.println(nombre + " avanzó " + distancia + " kms.\nCombustible restante: " + combustible + " litros.");
        } else {
            System.out.println("No hay suficiente combustible para avanzar " + distancia + " km. Realice una recarga.");
        }
    }
    
        public void despegar() { // SUPONIENDO QUE DESPEGAR CUESTE 15 COMB
        if (combustible >= 15) {
            combustible -= 15;
            System.out.println(nombre + " ha despegado. \nCombustible restante: " + combustible);
        } else {
            System.out.println("No hay suficiente combustible para despegar.");
        }
    }


// SETTERS

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCombustible(int combustible) {
        this.combustible = combustible;
    }

// GETTERS


    
    
    



    
}
