
package TP3_IntroPOO;


public class Estudiante {
/*Registro de Estudiantes
a. Crear una clase Estudiante con los atributos: nombre, apellido, curso, calificación.
Métodos requeridos: mostrarInfo(), subirCalificacion(puntos), bajarCalificacion(puntos).
Tarea: Instanciar a un estudiante, mostrar su información, aumentar y disminuir calificaciones.*/
 
    // ATRIBUTOS  
    String nombre;
    String apellido;
    String curso;
    Double calificacion;


 // MÉTODOS
    
    public void MostrarInfo() {
        System.out.println("Nombre: " + nombre + "\nApellido: " + apellido + "\nCurso: "                + curso + "\nCalificación: " + calificacion);
    }

    public double SubirCalificacion(double puntos){
        return calificacion += puntos;
    }
    
    public double BajarCalificacion(double puntos){
        return calificacion -= puntos;
    }
    
    
    
    
}
