
package TP3_IntroPOO;


public class Libro {
/*Encapsulamiento con la Clase Libro
a. Crear una clase Libro con atributos privados: titulo, autor, añoPublicacion.
Métodos requeridos: Getters para todos los atributos. Setter con validación para añoPublicacion.
Tarea: Crear un libro, intentar modificar el año con un valor inválido y luego con uno válido, mostrar la información final.*/ 
    
// ATRIBUTOS
    
private String titulo;
private String autor;
private int añoPublicacion;

// MÉTODOS

    public void MostrarInfo() {
        System.out.println("Información del libro: \nTítulo: " + titulo + "\nAutor/es: " + autor + "\nAño de publicación: " + añoPublicacion);
      }


// GETTERS

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public int getAñoPublicacion() {
        return añoPublicacion;
    }
    

 
// SETTERS
    
    public void setAñoPublicacion(int añoPublicacion) {
        if (añoPublicacion > 0 && añoPublicacion <= 2025){
            this.añoPublicacion = añoPublicacion;
        } else
            System.out.println("Por favor, ingrese un año de publicación válido");
        
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }
    
    
   

}
