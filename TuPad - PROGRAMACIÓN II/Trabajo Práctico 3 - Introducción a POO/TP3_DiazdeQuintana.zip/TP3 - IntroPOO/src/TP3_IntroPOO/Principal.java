
package TP3_IntroPOO;

public class Principal {

    public static void main(String[] args) {
          
System.out.println("---------------- EJERCICIO 1 - CLASS ESTUDIANTE ----------------");

Estudiante melisa = new Estudiante();
melisa.nombre = "Melisa";
melisa.apellido = "Díaz de Quintana";
melisa.curso = "Programación II";
melisa.calificacion = 3.25;

melisa.MostrarInfo();

Double subirCalif = melisa.SubirCalificacion(6);
System.out.println("Calificación actualizada: " + subirCalif);

Double bajarCalif = melisa.BajarCalificacion(3);
System.out.println("Calificación actualizada: " + bajarCalif);


System.out.println("---------------- EJERCICIO 2 - CLASS MASCOTA ----------------");

Mascota hendrix = new Mascota();
hendrix.nombre = "Hendrix";
hendrix.especie = "Gato";
hendrix.edad = 2;

hendrix.MostrarInfo();

hendrix.CumplirAnios();

hendrix.MostrarInfo();

hendrix.CumplirAnios();


System.out.println("---------------- EJERCICIO 3 - CLASS LIBRO ---------------- ");

Libro ABC = new Libro();

ABC.setTitulo("ABC");
ABC.setAutor("Melisa DdQ");
ABC.setAñoPublicacion(2001);

ABC.MostrarInfo();

ABC.setAñoPublicacion(3200);

ABC.MostrarInfo();

ABC.setAñoPublicacion(1991);

ABC.MostrarInfo();


System.out.println("---------------- EJERCICIO 4 - CLASS GALLINA ----------------");

 Gallina gallina1 = new Gallina();
 Gallina gallina2 = new Gallina();
 
System.out.println("----- Gallina 1 ------");

gallina1.setIdGallina("015-2025");
gallina1.setEdad(4);
 
 gallina1.ponerHuevo();
 gallina1.ponerHuevo();
 gallina1.ponerHuevo();
 gallina1.MostrarEstado();
 gallina1.ponerHuevo();
 gallina1.MostrarEstado();
  
 gallina1.envejecer();
 gallina1.MostrarEstado();

 gallina1.envejecer();
 gallina1.MostrarEstado(); 
 
 System.out.println("----- Gallina 2 -----");
 
 gallina2.setIdGallina("554-2024");
 gallina2.setEdad(11);
    
 gallina2.ponerHuevo();
 gallina2.ponerHuevo();
 gallina2.ponerHuevo();
 gallina2.ponerHuevo();
 gallina2.MostrarEstado();

 
 gallina2.envejecer();
 gallina2.MostrarEstado();

 
System.out.println("---------------- EJERCICIO 5 - CLASS NAVE ESPACIAL ----------------");

NaveEspacial nave1 = new NaveEspacial();

nave1.setNombre("Nave 1");
nave1.setCombustible(50);

nave1.MostrarEstado();

nave1.despegar();

nave1.avanzar(26);
nave1.MostrarEstado();

nave1.recargarCombustible(45);
nave1.MostrarEstado();

nave1.avanzar(26);
nave1.MostrarEstado();    
    
  
    
    
    
    }

}
