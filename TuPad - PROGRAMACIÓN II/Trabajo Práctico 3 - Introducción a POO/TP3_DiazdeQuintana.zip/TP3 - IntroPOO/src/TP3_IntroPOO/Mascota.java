
package TP3_IntroPOO;


public class Mascota {
/*Registro de Mascotas
a. Crear una clase Mascota con los atributos: nombre, especie, edad.
Métodos requeridos: mostrarInfo(), cumplirAnios().
Tarea: Crear una mascota, mostrar su información, simular el paso del tiempo y verificar los cambios.*/

// ATRIBUTOS 
    
 String nombre;
 String especie;
 int edad;
    

// MÉTODOS
 
     public void MostrarInfo() {
        System.out.println("Nombre: " + nombre + "\nEspecie: " + especie + "\nEdad: " + edad);
      }
    
    public void CumplirAnios() {
             this.edad += 1;
        System.out.println("¡" + nombre + " cumplió un año más! Ahora tiene " + edad + " años.");
    }
    
    
}
