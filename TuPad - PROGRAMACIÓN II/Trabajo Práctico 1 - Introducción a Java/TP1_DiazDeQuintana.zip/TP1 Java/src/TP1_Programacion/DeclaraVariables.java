
package TP1_Programacion;

public class DeclaraVariables {

    public static void main(String[] args) {
    
/*Crea un programa que declare las siguientes variables con valores asignados:
a. String nombre
b. int edad
c. double altura
d. boolean estudiante
Imprime los valores en pantalla usando System.out.println().*/
    
    String nombre = "Melisa";
    int edad = 34;
    double altura = 1.69;
    boolean estudiante = true;
    
    System.out.println("Mi nombre es: " + nombre);
    System.out.println("Mi edad es: " + edad);
    System.out.println("Mi altura es: " + altura);
    System.out.println("Soy estudiante de la tecnicatura universitaria en Programación: " + estudiante);
  
    
    }

}
