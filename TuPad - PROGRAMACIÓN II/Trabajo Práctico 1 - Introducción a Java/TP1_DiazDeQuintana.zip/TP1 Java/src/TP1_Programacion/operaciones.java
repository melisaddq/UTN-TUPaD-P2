
package TP1_Programacion;

import java.util.Scanner;

public class operaciones {
/*Escribe un programa que solicite dos números enteros y realice las siguientes operaciones:
a. Suma
b. Resta
c. Multiplicación
d. División
Muestra los resultados en la consola.*/  
public static void main(String[] args) {
    
    Scanner input = new Scanner(System.in);
    int num1, num2;
    
    System.out.println("Vamos a realizar las operaciones aritméticas básicas con dos números");
       
    System.out.println("Por favor, ingrese el primer número: ");
    num1 = input.nextInt();
    
    System.out.println("Por favor, ingrese el segundo numero: ");
    num2 = input.nextInt();
    
    //OPERACIONES
    
    int suma = num1 + num2;
    int resta = num1 - num2;
    int multiplicacion = num1 * num2;
    int division = num1 / num2;
    int resto = num1 % num2;
    
    System.out.println("El resultado de la suma de " + num1 + " y " + num2 + " es igual a " + suma);
    System.out.println("El resultado de la resta entre " + num1 + " y " + num2 + " es igual a " + resta);
    System.out.println("El resultado de la multiplicación de " + num1 + " por " + num2 + " es igual a " + multiplicacion);
    System.out.println("El resultado de la división de " + num1 + " por " + num2 + " es " + division + " y arroja un resto de " + resto);    

}
}
