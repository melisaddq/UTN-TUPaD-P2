
package TP1_Programacion;


public class HolaMundo {

    /**
     * @param args the command line arguments
     */
public static void main(String[] args) {
     System.out.println("¡Hola, Java!");

    }
 }
    

