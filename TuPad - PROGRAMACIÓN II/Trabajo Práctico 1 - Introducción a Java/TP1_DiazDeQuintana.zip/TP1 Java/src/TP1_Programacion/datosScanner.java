
package TP1_Programacion;

import java.util.Scanner;


public class datosScanner {
/*Escribe un programa que solicite al usuario ingresar su nombre y edad, 
y luego los muestre en pantalla. Usa Scanner para capturar los datos. */

public static void main(String[] args) {
    
    Scanner input = new Scanner(System.in);
    String nombre;
    int edad;
       
    System.out.println("Por favor, ingrese su nombre: ");
    nombre = input.nextLine();
    
    System.out.println("Por favor, ingrese su edad: ");
    edad = input.nextInt();
    
    System.out.println("Usted se llama " + nombre + " y tiene " + edad + " años");    

    } 
}
