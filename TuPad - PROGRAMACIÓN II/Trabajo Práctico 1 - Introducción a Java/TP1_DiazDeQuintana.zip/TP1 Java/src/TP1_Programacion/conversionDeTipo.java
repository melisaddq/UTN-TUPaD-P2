
package TP1_Programacion;

import java.util.Scanner;


public class conversionDeTipo {
    
/* Manejar conversiones de tipo y división en Java. 
Escribe un programa que divida dos números enteros ingresados por el usuario. 
Modifica el código para usar double en lugar de int y compara los resultados. */

    public static void main(String[] args) {
        
Scanner input = new Scanner(System.in);
    int num1, num2;
       
    System.out.println("Por favor, ingrese el primer número: ");
    num1 = input.nextInt();
    
    System.out.println("Por favor, ingrese el segundo número: ");
    num2 = input.nextInt();
    
    //OPERACION
    
    int division = num1 / num2;
    double divisionDouble =(double) num1 / num2;

    System.out.println("El resultado de " + num1 + " dividido " + num2 + " es " + division);
    System.out.println("El resultado de " + num1 + " dividido " + num2 + " es " + divisionDouble + " utilizando double");
       
}
    }
