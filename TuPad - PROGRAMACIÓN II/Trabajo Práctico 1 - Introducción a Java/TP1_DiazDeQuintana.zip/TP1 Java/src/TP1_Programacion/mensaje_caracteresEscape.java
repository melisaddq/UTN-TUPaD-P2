
package TP1_Programacion;

public class mensaje_caracteresEscape {
    
/* Escribe un programa que muestre el siguiente mensaje en consola:
Nombre: Juan Pérez
Edad: 30 años
Dirección: "Calle Falsa 123"
Usa caracteres de escape (\n, \") en System.out.println()*/
    
public static void main(String[] args) {
   
    //Muestra por consola
    
    System.out.println(" Nombre: Juan Pérez \n Edad: 30 años \n Dirección: Calle Falsa 123");
}
}