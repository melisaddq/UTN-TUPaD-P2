
package TP2_Programacion;

import java.util.Scanner;


public class costoEnvio {
    
/*Composición de funciones para calcular costo de envío y total de compra.

a. calcularCostoEnvio(double peso, String zona): Calcula el costo de envío 
basado en la zona de envío (Nacional o Internacional) y el peso del paquete.
Nacional: $5 por kg
Internacional: $10 por kg

b. calcularTotalCompra(double precioProducto, double costoEnvio): 
Usa calcularCostoEnvio para sumar el costo del producto con el costo de envío.

Desde main(), solicita el peso del paquete, la zona de envío y el precio del producto. 
Luego, muestra el total a pagar.
    
Ejemplo de entrada/salida:
Ingrese el precio del producto: 50
Ingrese el peso del paquete en kg: 2
Ingrese la zona de envío (Nacional/Internacional): Nacional
El costo de envío es: 10.0
El total a pagar es: 60.0*/

public static void main(String[] args) {
   
   Scanner input = new Scanner(System.in);  
   
double pesoPaquete, precioProd;
String zonaEnvio;
    
    
    
System.out.println("Por favor, ingrese el peso del paquete en kg: ");
pesoPaquete = input.nextDouble();
input.nextLine();
System.out.println("Por favor, ingrese la zona de envío (Nacional/Internacional): "); // Nac 5*kg // int 10*kg
zonaEnvio = input.nextLine();
System.out.println("Por favor, ingrese el precio del producto: ");
precioProd = input.nextDouble();   
        
   
double costoEnvio = calcularCostoEnvio (pesoPaquete, zonaEnvio);      
double totalCompra = calcularTotalCompra (precioProd, costoEnvio);  

System.out.println("El costo del envío es $" + costoEnvio + ", y el precio total a pagar es $" + totalCompra);    
    
    
}  


static double calcularCostoEnvio (double peso, String zona) {
    double envio;
    if (zona.equalsIgnoreCase("Nacional")) {
        envio = (peso * 5);
    } else {
        envio = (peso * 10);
    } return envio;
}


static double calcularTotalCompra(double precioProducto, double costoEnvio) {
    double precioTotal = (precioProducto + costoEnvio);
return precioTotal;
}
    




}
