
package TP2_Programacion;

import java.util.Scanner;
import java.util.Locale;

public class variableGlobal {
/*Cálculo de descuento especial usando variable global.
Declara una variable global Ejemplo de entrada/salida: = 0.10. 
Luego, crea un método calcularDescuentoEspecial(double precio) 
que use la variable global para calcular el 
descuento especial del 10%.
Dentro del método, declara una variable local descuentoAplicado, 
almacena el valor del descuento y muestra el precio final con descuento.
Ejemplo de entrada/salida:
Ingrese el precio del producto: 200
El descuento especial aplicado es: 20.0
El precio final con descuento es: 180.0*/

final static double PORCENTAJEDESCUENTO = 0.10;    
    
public static void main(String[] args) {
Locale.setDefault(Locale.US);    
    
Scanner input = new Scanner(System.in);

double precioProd, precioFinal;

    
    
System.out.println("Por favor, ingrese el precio del producto: $"); 
precioProd = input.nextDouble();
input.nextLine();
System.out.println("El descuento especial aplicado es del " + (PORCENTAJEDESCUENTO * 100) + "%.");
precioFinal = calcularDescuentoEspecial(precioProd);
System.out.println("El precio final con descuento es: $" + precioFinal);
    
 
 
    
}

static double calcularDescuentoEspecial(double precio){
    double descuentoAplicado = precio - (precio * PORCENTAJEDESCUENTO);
    return descuentoAplicado;
}

}
