
package TP2_Programacion;

import java.util.Locale;


public class modifArrayRecursivo {
    
    /*Impresión recursiva de arrays antes y después de modificar un elemento.
Crea un programa que:
a. Declare e inicialice un array con los precios de algunos productos.
b. Use una función recursiva para mostrar los precios originales.
c. Modifique el precio de un producto específico.
d. Use otra función recursiva para mostrar los valores modificados.*/

    public static void main(String[] args) {
        Locale.setDefault(Locale.US);

        // declarar e inicializar
        double[] precios = {199.99, 299.5, 149.75, 399.0, 89.99};

        // mostrar valores originales
        System.out.println("Los precios originales del array son: ");
        mostrarPrecios(precios, 0);

        //modificar
        precios[2] = 129.99;

        // mostrar valores modificados
        System.out.println("\nLos precios modificados del array son: ");
        mostrarPrecios(precios, 0);
    }

    // función recursiva para mostrar precios
    static void mostrarPrecios(double[] precio, int indice) {
        if (indice >= precio.length) {
            return; 
        }
        System.out.println("$" + precio[indice]);
        mostrarPrecios(precio, indice + 1);
 
     }
}



