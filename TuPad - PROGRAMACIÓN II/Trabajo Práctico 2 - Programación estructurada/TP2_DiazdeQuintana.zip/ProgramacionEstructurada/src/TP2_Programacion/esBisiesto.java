
package TP2_Programacion;

import java.util.Scanner;


public class esBisiesto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /* Escribe un programa en Java que solicite al usuario un año y 
        determine si es bisiesto. Un año es bisiesto si es divisible por 4, 
        pero no por 100, salvo que sea divisible por 400.*/
        
          Scanner input = new Scanner(System.in);
          int anioIngresado;
          
          System.out.println("Por favor, ingrese un año para determinar si es bisiesto: ");
          anioIngresado = input.nextInt();
          esBisiesto(anioIngresado);
                          
    }
    
    static void esBisiesto(int anio) {
        boolean esBisiesto = (anio % 4 == 0 && anio % 100 != 0) || (anio % 400 == 0);
        if (esBisiesto)
            System.out.println("El año " + anio + " es bisiesto");
        else 
            System.out.println("El año " + anio + " no es bisiesto");
    }

}
