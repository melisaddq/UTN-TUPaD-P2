
package TP2_Programacion;

import java.util.Scanner;


public class precioFinal {
    /*Cálculo del Precio Final con impuesto y descuento.
    Crea un método calcularPrecioFinal(double impuesto, double descuento) 
    que calcule el precio final de un producto en un e-commerce. La fórmula es:
    PrecioFinal = PrecioBase + (PrecioBase×Impuesto) − (PrecioBase×Descuento) 
    PrecioFinal = PrecioBase + (PrecioBase \times Impuesto) - (PrecioBase \times Descuento)
    Desde main(), solicita el precio base del producto, el porcentaje de impuesto y el porcentaje de descuento, 
    llama al método y muestra el precio final.*/

   public static void main(String[] args) {
   
   Scanner input = new Scanner(System.in);
   double precioBase, impuesto, descuento;
 
   
   System.out.println("Por favor, ingrese el precio base del producto: ");
   precioBase = input.nextDouble();
   input.nextLine();
   System.out.println("Por favor, el porcentaje del impuesto: ");
   impuesto = input.nextDouble();
   input.nextLine();
   System.out.println("Por favor, ingrese el porcentaje del descuento: ");
   descuento = input.nextDouble();

   System.out.println("El precio final del producto es: $" + calcularPrecioFinal(precioBase, impuesto, descuento));
      
   } 
   
    static double calcularPrecioFinal(double precioInicial, double imp, double desc){
       double PrecioFinal = precioInicial + (precioInicial * imp / 100) - (precioInicial * desc / 100); 
       return PrecioFinal;
   }
           
}
