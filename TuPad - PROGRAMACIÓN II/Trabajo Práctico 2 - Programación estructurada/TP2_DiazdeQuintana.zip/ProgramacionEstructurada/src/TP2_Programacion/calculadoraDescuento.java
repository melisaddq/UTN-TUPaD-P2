
package TP2_Programacion;

import java.util.Locale;
import java.util.Scanner;


public class calculadoraDescuento {
    
/*Calculadora de Descuento según categoría.
Escribe un programa que solicite al usuario el precio de un producto y su categoría (A, B o C).
Luego, aplique los siguientes descuentos:
Categoría A: 10% de descuento
Categoría B: 15% de descuento
Categoría C: 20% de descuento
El programa debe mostrar el precio original, el descuento aplicado y el precio final*/
    
    public static void main(String[] args) {
    Locale.setDefault(Locale.US);
        
    Scanner input = new Scanner(System.in);
    double precio;
    char categoria;
        
    System.out.print("Por favor, ingrese el precio del producto: ");
    precio = input.nextDouble();
    input.nextLine();
    System.out.print("Por favor, ingrese la categoría A, B o C: ");
    categoria = input.nextLine().charAt(0);
    
    double descuento = (double) precioConDescuento (precio, categoria);
    double precioFinal =  (double) precio - descuento;
    
   
    System.out.println("Precio originial:  $" + precio + 
            "\nDescuento aplicado: " + porcentaje(categoria) + 
            "%\nPrecio final: $" + precioFinal);
          
        
    }
    
    static double precioConDescuento(double precio, char cat) {
        switch (cat) {
            case 'A':
                return (precio * 0.10);
            case 'B':
                return (precio * 0.15);
            default:
                return (precio * 0.20);
        }
    
    }
    
        static int porcentaje (char letra){
        switch (letra) {
            case 'A':
                return 10;
            case 'B':
                return 15;
            default:
                return 20;
        }
        }
    }
