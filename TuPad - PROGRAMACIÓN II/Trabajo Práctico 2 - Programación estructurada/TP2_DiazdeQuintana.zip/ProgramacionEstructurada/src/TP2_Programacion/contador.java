
package TP2_Programacion;

import java.util.Scanner;


public class contador {
    
    /*Contador de Positivos, Negativos y Ceros (for).
    Escribe un programa que pida al usuario ingresar 10 números 
    enteros y cuente cuántos son positivos, negativos y cuántos son ceros.*/
    
    public static void main(String[] args) {    
    Scanner input = new Scanner(System.in);
    
    int num;
    int sumaPositivos = 0;
    int sumaNegativos = 0;
    int sumaCeros = 0;
    
            for (int i = 0; i < 10; i++) {
            System.out.print("Por favor, ingrese un número entero: ");
            num = input.nextInt();
                        
            if (num == 0) {
                sumaCeros += 1;
            } else if (num > 0) {
                    sumaPositivos += 1;
            } else {
                    sumaNegativos += 1;
            }
        }
    System.out.println("Resultados:");
    System.out.println("Cantidad de positivos: " + sumaPositivos);
    System.out.println("Cantidad de negativos: " + sumaNegativos);
    System.out.println("Cantidad de ceros: " + sumaCeros);

        
    }
    
    
    
    
    
    
    
}


