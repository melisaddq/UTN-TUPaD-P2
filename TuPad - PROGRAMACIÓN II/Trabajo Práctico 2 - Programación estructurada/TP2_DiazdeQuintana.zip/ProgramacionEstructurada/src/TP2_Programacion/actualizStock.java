
package TP2_Programacion;

import java.util.Scanner;


public class actualizStock {
    
/*Actualización de stock a partir de venta y recepción de productos.
Crea un método actualizarStock(int stockActual, int cantidadVendida,
int cantidadRecibida), 
que calcule el nuevo stock después de una venta y recepción
de productos:
NuevoStock = StockActual − CantidadVendida + CantidadRecibida
NuevoStock = CantidadVendida + CantidadRecibida
Desde main(), solicita al usuario el stock actual, la cantidad vendida y 
la cantidad recibida, y muestra el stock actualizado.*/
       
  public static void main(String[] args) {
  
  
  Scanner input = new Scanner(System.in);

int stockActual, stockVendidos, stockRecibidos;
  
  
System.out.println("Por favor, ingrese el stock actual: ");
stockActual = input.nextInt();
System.out.println("Por favor, ingrese la cantidad de productos vendidos: "); 
stockVendidos = input.nextInt();
System.out.println("Por favor, ingrese la cantidad de productos recibidos: ");
stockRecibidos = input.nextInt(); 
  
  
 int stockActualizado = actualizarStock(stockActual, stockVendidos, stockRecibidos);
 
 System.out.println("El nuevo stock del producto es: " + stockActualizado); 
  
  
  }

static int actualizarStock(int actual, int vendidos, int recibidos) {
    int NuevoStock = actual - vendidos + recibidos;
    return NuevoStock; 
}
  

}
