
package TP2_Programacion;

import java.util.Scanner;


public class sumaNumPares {
/*Suma de Números Pares (while).
Escribe un programa que solicite números al usuario y sume solo los números pares. 
El ciclo debe continuar hasta que el usuario ingrese el número 0, momento en el que 
se debe mostrar la suma total de los pares ingresados.
Ejemplo de entrada/salida:
Ingrese un número (0 para terminar): 4
Ingrese un número (0 para terminar): 7
Ingrese un número (0 para terminar): 2
Ingrese un número (0 para terminar): 0
La suma de los números pares es: 6
3*/    

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int sumatoria = 0;
        int num;

        System.out.print("Por favor, ingrese un número (cero para terminar): ");
        num = input.nextInt();

        while (num != 0) {
            sumatoria = sumaPares(sumatoria, num); 
            System.out.print("Por favor, ingrese un número (cero para terminar): ");
            num = input.nextInt();
        }

        System.out.println("La sumatoria de números pares es: " + sumatoria);
    }

    static int sumaPares(int sumaPar, int n) {
        if (n % 2 == 0) {
            sumaPar += n;
        }
        return sumaPar;
    }
}



  

 
