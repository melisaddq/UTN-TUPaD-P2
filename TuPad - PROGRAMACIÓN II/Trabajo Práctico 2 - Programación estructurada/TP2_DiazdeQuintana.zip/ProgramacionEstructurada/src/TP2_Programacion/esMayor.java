
package TP2_Programacion;

import java.util.Scanner;


public class esMayor {
/*Determinar el Mayor de Tres Números.
Escribe un programa en Java que pida al usuario tres 
números enteros y determine cuál es el mayor.*/
    
    public static void main(String[] args) {
    
    Scanner input = new Scanner(System.in);
    int num1, num2, num3;
    
    System.out.println("Vamos a determinar cuál de los tres números enteros ingresados es el mayor ");
    System.out.println("Por favor, ingrese el primer número: ");
    num1 = input.nextInt();
    System.out.println("Por favor, ingrese el segundo número: ");
    num2 = input.nextInt();
    System.out.println("Por favor, ingrese el tercer número: ");
    num3 = input.nextInt();
     
    System.out.println("El mayor es " + esMayor(num1, num2, num3));  
            
    }
    
    static int esMayor (int n1, int n2, int n3){
        if (n1>n2 && n1>n3) {
            return n1;
        } else if (n2>n1 && n2>n3) {
                return n2;
        } else
                return n3;
        }
    }


